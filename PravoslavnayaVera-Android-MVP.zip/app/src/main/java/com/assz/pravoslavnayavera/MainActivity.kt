package com.assz.pravoslavnayavera

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Parchment = Color(0xFFF1E4C8)
private val Paper = Color(0xFFFAF2DF)
private val Ink = Color(0xFF3C281D)
private val Burgundy = Color(0xFF702B32)
private val Gold = Color(0xFFB28A45)
private val MutedInk = Color(0xFF806A55)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OrthodoxBookApp() }
    }
}

private data class BookSection(val title: String, val subtitle: String)

private val books = listOf(
    BookSection("Книга первая", "О Божестве и творении"),
    BookSection("Книга вторая", "О мире и человеке"),
    BookSection("Книга третья", "О Христе и спасении"),
    BookSection("Книга четвёртая", "О таинствах и последних событиях")
)

@Composable
fun OrthodoxBookApp() {
    var selectedBook by remember { mutableStateOf<BookSection?>(null) }
    var search by remember { mutableStateOf("") }
    var bookmarked by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = lightColorScheme(
        background = Parchment, surface = Paper, primary = Burgundy, onPrimary = Paper,
        onBackground = Ink, onSurface = Ink
    )) {
        Surface(modifier = Modifier.fillMaxSize(), color = Parchment) {
            if (selectedBook == null) {
                Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 18.dp)) {
                    Spacer(Modifier.height(12.dp))
                    Text("✥", color = Gold, fontSize = 28.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                    Text("ПРАВОСЛАВНАЯ ВЕРА", color = Burgundy, fontSize = 23.sp,
                        fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp,
                        textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    Text("СОКРОВИЩЕ ЦЕРКОВНОГО ПРЕДАНИЯ", color = MutedInk, fontSize = 9.sp,
                        letterSpacing = 2.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(22.dp))
                    Surface(
                        color = Burgundy, shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().height(218.dp)
                    ) {
                        Column(Modifier.fillMaxSize().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center) {
                            Text("✝", color = Gold, fontSize = 42.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("ТОЧНОЕ ИЗЛОЖЕНИЕ\nПРАВОСЛАВНОЙ ВЕРЫ",
                                color = Color(0xFFF6E8C8), fontSize = 19.sp, fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center, lineHeight = 27.sp)
                            Spacer(Modifier.height(12.dp))
                            Text("Святитель Иоанн Дамаскин", color = Color(0xFFE2C98E), fontSize = 13.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("❦", color = Gold, fontSize = 22.sp)
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                    Text("СОДЕРЖАНИЕ", color = Burgundy, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = search, onValueChange = { search = it },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        placeholder = { Text("Поиск по разделам…", color = MutedInk) },
                        leadingIcon = { Icon(Icons.Default.Search, null, tint = Burgundy) },
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Gold, unfocusedBorderColor = Color(0xFFD2BE99),
                            focusedTextColor = Ink, unfocusedTextColor = Ink, cursorColor = Burgundy
                        )
                    )
                    Spacer(Modifier.height(10.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        items(books.filter { it.title.contains(search, true) || it.subtitle.contains(search, true) }) { book ->
                            Surface(color = Paper, shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth().clickable { selectedBook = book }) {
                                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.MenuBook, null, tint = Burgundy, modifier = Modifier.size(25.dp))
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(book.title, color = Burgundy, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                        Text(book.subtitle, color = MutedInk, fontSize = 12.sp)
                                    }
                                    Text("›", color = Gold, fontSize = 27.sp)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("ПЕРВОЕ ИЗДАНИЕ • ЭЛЕКТРОННАЯ БИБЛИОТЕКА",
                        color = MutedInk, fontSize = 9.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth())
                }
            } else {
                Column(Modifier.fillMaxSize().padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { selectedBook = null }) {
                            Icon(Icons.Default.ArrowBack, "Назад", tint = Burgundy)
                        }
                        Text("К содержанию", color = Burgundy, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.weight(1f))
                        IconButton(onClick = { bookmarked = !bookmarked }) {
                            Icon(Icons.Default.Bookmark, "Закладка",
                                tint = if (bookmarked) Gold else MutedInk)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text(selectedBook!!.title.uppercase(), color = Burgundy, fontSize = 12.sp,
                        letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(selectedBook!!.subtitle, color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(18.dp))
                    Surface(color = Paper, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxSize()) {
                        Column(Modifier.padding(20.dp)) {
                            Text("О тексте", color = Burgundy, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Spacer(Modifier.height(12.dp))
                            Text(
                                "Здесь будет размещён полный текст соответствующей части книги «Точное изложение православной веры» святителя Иоанна Дамаскина на русском языке.\n\n" +
                                "Чтобы не исказить святоотеческий труд, текст необходимо внести по выбранному русскому переводу и сверить с изданием. Этот экран пока является макетом читалки.",
                                color = Ink, fontSize = 16.sp, lineHeight = 26.sp
                            )
                            Spacer(Modifier.height(18.dp))
                            Text(if (bookmarked) "Закладка сохранена в текущем сеансе." else "Нажмите значок закладки, чтобы отметить раздел.",
                                color = MutedInk, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
